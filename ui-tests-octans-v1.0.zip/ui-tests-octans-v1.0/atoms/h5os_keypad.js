
'use strict';
/* global SpecialPowers */


/**
 * The keyboard events occur in a specific sequence:
 *   After press key >> mozbrowserbeforekeydown, keydown, mozbrowserafterkeydown
 *   After release key >> mozbrowserbeforekeyup, keyup, mozbrowserafterkeyup.
 * So, we need to simulate send 'keydown' at first and then send 'keyup' after receiving 'mozbrowserafterkeydown'
 ***
 * Two targets of our simulated events: system (window) & specific app
 * system: SpecialPowers.DOMWindowUtils.sendKeyEvent(...)
 * specific app: SpecialPowers.DOMWindowUtils.dispatchDOMEventViaPresShell(...);
 */

const DOM_KEY_LOCATION_MOBILE = 4;

var h5OSKeypad = {

  /*
   * press LSK, RSK, OK, Call, EndCall to specific app (iframe)
   * https://jira.acadine.com/browse/CORE-18
   */
  pressSoftKey: function(keyName, keyCode, iframe, toSystem) {
    h5OSKeypad._sendEventToApp(keyName, keyCode, iframe, DOM_KEY_LOCATION_MOBILE, toSystem);
  },

  /*
   * send events to system
   */
  _sendEventToSystem: function(keyCode) {

    //XXX: 'sendKeyEvent' would be changed to nslTextInputProcessor in next version
    //     https://developer.mozilla.org/en-US/docs/Mozilla/Tech/XPCOM/Reference/Interface/nsITextInputProcessor
    OnceEventAction.addOneTimeEventListener(window, 'mozbrowserafterkeydown', function(e) {
        SpecialPowers.DOMWindowUtils.sendKeyEvent('keyup',keyCode, 0, 0);
    }, false);

    SpecialPowers.DOMWindowUtils.sendKeyEvent('keydown', keyCode, 0, 0);
  },

  /*
   * send events to specific app
   */
  _sendEventToApp: function(keyName, keyCode, target, location, toSystem) {

    var keyupEvent = h5OSKeypad.newKeyboardEvent('keyup', keyName, keyCode, location),
        keydownEvent = h5OSKeypad.newKeyboardEvent('keydown', keyName, keyCode, location);

    if(toSystem) {
        SpecialPowers.DOMWindowUtils.dispatchDOMEventViaPresShell(target, keydownEvent, true);
        SpecialPowers.DOMWindowUtils.dispatchDOMEventViaPresShell(target, keyupEvent, true);
    } else {
        OnceEventAction.addOneTimeEventListener(window, 'mozbrowserafterkeydown',function(e) {
            SpecialPowers.DOMWindowUtils.dispatchDOMEventViaPresShell(target, keyupEvent, true);
        }, false);

        SpecialPowers.DOMWindowUtils.dispatchDOMEventViaPresShell(target, keydownEvent, true);
    }
  },

  newKeyboardEvent: function(eventName, keyName, keyCode, location) {
    var eventContent = { key: keyName,
                        keyCode: keyCode,
                        which: keyCode,
                        altKey: false,
                        ctrlKey: false,
                        metaKey: false,
                        shiftKey: false,
                        bubbles: true,
                        cancelable: true,
                        location: location
                      };
    return new KeyboardEvent(eventName, eventContent);
   }
};

/**
 * new a one time action after receiving a specific event
 */
var OnceEventAction = {
  once: function(target, type, listener, useCapture) {
    var capture = !!useCapture;
    target.addEventListener(type, handler, capture);

    function deregister() {
        target.removeEventListener(type, handler, capture);
    }

    function handler() {
        deregister();
        return listener.apply(this, arguments);
    }

    return deregister;
  },

  addOneTimeEventListener: function(target, type, listener, useCapture) {
    OnceEventAction.once(target, type, listener, useCapture);
  }
};