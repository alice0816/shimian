App manager
===========

.. autoclass:: gaiatest.gaia_test.GaiaApps
   :members:
   :undoc-members:
