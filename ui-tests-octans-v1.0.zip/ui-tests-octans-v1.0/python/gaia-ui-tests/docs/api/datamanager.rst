Data manager
============

.. autoclass:: gaiatest.gaia_test.GaiaData
   :members:
   :undoc-members:
