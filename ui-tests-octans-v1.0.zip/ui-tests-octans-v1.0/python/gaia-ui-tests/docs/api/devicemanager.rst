Device manager
==============

.. autoclass:: gaiatest.gaia_test.GaiaDevice
   :members:
   :undoc-members:
