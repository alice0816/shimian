File manager
============

.. automodule:: gaiatest.file_manager
   :members:
