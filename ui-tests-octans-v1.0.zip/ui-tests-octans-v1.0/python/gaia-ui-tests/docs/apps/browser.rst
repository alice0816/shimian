Browser
=======

.. automodule:: gaiatest.apps.browser.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.browser.regions.html5_player
   :members:
   :show-inheritance:
   :undoc-members:
