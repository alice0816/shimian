Calendar
========

.. automodule:: gaiatest.apps.calendar.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.calendar.regions.event
   :members:
   :show-inheritance:
   :undoc-members:
