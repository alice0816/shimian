Clock
=====

.. automodule:: gaiatest.apps.clock.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.clock.regions.alarm
   :members:
   :show-inheritance:
   :undoc-members:
