Contacts
========

.. automodule:: gaiatest.apps.contacts.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.contacts.regions.contact_details
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.contacts.regions.contact_form
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.contacts.regions.contact_import_picker
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.contacts.regions.gmail
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.contacts.regions.settings_form
   :members:
   :show-inheritance:
   :undoc-members:
