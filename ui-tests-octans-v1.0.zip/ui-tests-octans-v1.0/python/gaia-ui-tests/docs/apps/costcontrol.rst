Cost control
============

.. automodule:: gaiatest.apps.cost_control.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.cost_control.regions.ftu_step1
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.cost_control.regions.ftu_step2
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.cost_control.regions.ftu_step3
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.cost_control.regions.settings
   :members:
   :show-inheritance:
   :undoc-members:
