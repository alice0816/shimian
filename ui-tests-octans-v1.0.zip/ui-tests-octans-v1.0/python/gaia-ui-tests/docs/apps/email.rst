Email
=====

.. automodule:: gaiatest.apps.email.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.email.regions.new_email
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.email.regions.read_email
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.email.regions.settings
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.email.regions.setup
   :members:
   :show-inheritance:
   :undoc-members:
