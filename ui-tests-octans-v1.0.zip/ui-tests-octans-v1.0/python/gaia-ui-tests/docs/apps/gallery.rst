Gallery
=======

.. automodule:: gaiatest.apps.gallery.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.gallery.regions.crop_view
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.gallery.regions.edit_photo
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.gallery.regions.fullscreen_image
   :members:
   :show-inheritance:
   :undoc-members:
