Homescreen
==========

.. automodule:: gaiatest.apps.homescreen.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.homescreen.regions.bookmark_menu
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.collections
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.collections_activity
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.confirm_dialog
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.confirm_install
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.context_menu
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.permission_dialog
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.homescreen.regions.search_panel
   :members:
   :show-inheritance:
   :undoc-members:
