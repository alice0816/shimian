Lockscreen
==========

.. automodule:: gaiatest.apps.lockscreen.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.lockscreen.regions.passcode_pad
   :members:
   :show-inheritance:
   :undoc-members:
