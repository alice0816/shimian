Messages
========

.. automodule:: gaiatest.apps.messages.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.messages.regions.activities
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.messages.regions.message_thread
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.messages.regions.messaging_settings
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.messages.regions.new_message
   :members:
   :show-inheritance:
   :undoc-members:
