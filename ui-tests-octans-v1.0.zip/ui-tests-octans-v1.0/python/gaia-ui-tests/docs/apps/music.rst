Music
=====

.. automodule:: gaiatest.apps.music.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.music.regions.list_view
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.music.regions.player_view
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.music.regions.sublist_view
   :members:
   :show-inheritance:
   :undoc-members:
