Phone
=====

.. automodule:: gaiatest.apps.phone.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.phone.regions.attention_screen
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.phone.regions.call_log
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.phone.regions.call_screen
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.phone.regions.keypad
   :members:
   :show-inheritance:
   :undoc-members:
