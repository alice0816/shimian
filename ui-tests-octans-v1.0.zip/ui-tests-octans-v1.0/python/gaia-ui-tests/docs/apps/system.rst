System
======

.. automodule:: gaiatest.apps.system.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.system.regions.activities
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.system.regions.cards_view
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.system.regions.iac_publisher
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.system.regions.sleep_view
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.system.regions.status_bar
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.system.regions.utility_tray
   :members:
   :show-inheritance:
   :undoc-members:
