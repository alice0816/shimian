UI tests
========

.. automodule:: gaiatest.apps.ui_tests.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.ui_tests.regions.keyboard
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.ui_tests.regions.persona
   :members:
   :show-inheritance:
   :undoc-members:
