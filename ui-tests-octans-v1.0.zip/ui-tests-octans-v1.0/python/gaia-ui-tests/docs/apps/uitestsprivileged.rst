UI tests (privileged)
=====================

.. automodule:: gaiatest.apps.ui_tests_privileged.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.ui_tests_privileged.regions.contacts
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.ui_tests_privileged.regions.device_storage
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.ui_tests_privileged.regions.geolocation
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: gaiatest.apps.ui_tests_privileged.regions.user_media
   :members:
   :show-inheritance:
   :undoc-members:
