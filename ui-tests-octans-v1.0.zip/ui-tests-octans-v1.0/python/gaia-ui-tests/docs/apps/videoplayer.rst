Video
=====

.. automodule:: gaiatest.apps.videoplayer.app
   :members:
   :show-inheritance:
   :undoc-members:

Regions
-------

.. automodule:: gaiatest.apps.videoplayer.regions.fullscreen_video
   :members:
   :show-inheritance:
   :undoc-members:
