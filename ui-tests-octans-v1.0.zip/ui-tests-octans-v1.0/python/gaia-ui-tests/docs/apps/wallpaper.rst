Wallpaper
=========

.. automodule:: gaiatest.apps.wallpaper.app
   :members:
   :show-inheritance:
   :undoc-members:
