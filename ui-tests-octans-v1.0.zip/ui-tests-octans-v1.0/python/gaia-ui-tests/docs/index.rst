.. gaiatest documentation master file, created by
   sphinx-quickstart on Fri Jul 11 15:36:10 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Introduction
============

gaiatest is a Python package based on `Marionette <https://developer.mozilla.org/en-US/docs/Marionette>`_, which is designed specifically for writing tests against `Gaia <https://github.com/mozilla-b2g/gaia>`_.

.. toctree::
   :maxdepth: 2

   installation
   gcli
   testrunner
   writingtests
   api/index
   apps/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
