# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time

from marionette import expected
from marionette import Wait
from marionette.by import By
from marionette.errors import NoSuchElementException

from gaiatest.apps.base import Base
from gaiatest.apps.gallery.app import Gallery


class Camera(Base):

    ## TODO: Aca modifying...

    name = 'Camera'

    PHOTO_MODE = 'photo'
    VIDEO_MODE = 'video'

    _hud_flash_locator = (By.CSS_SELECTOR, '.hud_flash')

    _video_timer_locator = (By.CSS_SELECTOR, '.recording-timer')

    _viewfinder_ready_locator = (By.CSS_SELECTOR, '.viewfinder.js-viewfinder.visible[enabled="true"]')
    _viewfinder_not_ready_locator = (By.CSS_SELECTOR, '.viewfinder.js-viewfinder.visible[enabled="false"]')
    _viewfinder_video_locator = (By.CLASS_NAME, 'viewfinder-video')

    _notification_span_photo_mode_locator = (By.CSS_SELECTOR, '.notification span[data-l10n-id="Photo-Mode"]')
    _notification_span_video_mode_locator = (By.CSS_SELECTOR, '.notification span[data-l10n-id="Video-Mode"]')
    _notification_span_flash_on_locator = (By.CSS_SELECTOR, '.notification span[data-l10n-id="flash-on"]')
    _notification_span_flash_off_locator = (By.CSS_SELECTOR, '.notification span[data-l10n-id="flash-off"]')
    _notification_span_flash_auto_locator = (By.CSS_SELECTOR, '.notification span[data-l10n-id="flash-auto"]')

    _option_menu_locator = (By.CSS_SELECTOR, '.optionmenu.js-optionmenu h5-option-menu')
    _option_menu_flash_locator = (By.CSS_SELECTOR, '.h5-option-menu-item[data-title="flash"]')

    _option_menu_sub_panel_flash_on_locator =(By.CSS_SELECTOR, '.panel.sub-panel.active .h5-option-menu-item[data-key="on"]')
    _option_menu_sub_panel_flash_off_locator =(By.CSS_SELECTOR, '.panel.sub-panel.active .h5-option-menu-item[data-key="off"]')
    _option_menu_sub_panel_flash_auto_locator =(By.CSS_SELECTOR, '.panel.sub-panel.active .h5-option-menu-item[data-key="auto"]')

    _indicator_locator = (By.CSS_SELECTOR, '.indicators')

    def launch(self):
        Base.launch(self)
        self.wait_for_stream_capture_ready()

    @property
    def camera_mode(self):
        """
        :return: 'video' or 'photo'
        """
        if self.marionette.find_element(*self._indicator_locator).get_attribute('mode') == "video":
            return self.VIDEO_MODE
        elif self.marionette.find_element(*self._indicator_locator).get_attribute('mode') == "picture":
            return self.PHOTO_MODE
        elif not self.marionette.find_element(*self._indicator_locator).get_attribute('mode'): #default
            return self.PHOTO_MODE
        raise Exception("camera mode is not correct!")

    @property
    def current_flash_mode(self):
        """
        :return: 'flash-on', 'flash-off', or 'flash-auto'
        """
        return self.marionette.find_element(*self._hud_flash_locator).get_attribute('data-icon')

    @property
    def video_timer(self):
        text = self.marionette.find_element(*self._video_timer_locator).text
        return time.strptime(text, '%M:%S')

    def take_photo(self, numbers=1):
        for number in range(0, numbers):
            self.press_softkey_central_button()
            ## TODO: verify post-photo behavior after VD is ready

    def go_to_image_preview(self):
        """
        it would switch to Gallery frame
        :return:
        """
        try:
            self.wait_for_stream_capture_ready()
            self.press_softkey_left_button()
            imagePreview = ImagePreview(self.marionette)
            imagePreview.wait_for_gallery_ready()
            return imagePreview
        except:
            raise Exception('Go to image preview page failed...')

    def switch_flash(self, to='on'):
        """
        :param to: 'on', 'off', or 'auto'
        :return:
        """
        if self.current_flash_mode.split('-')[1] == to.lower():
            return

        self.__go_to_options_menu()
        target_element = self.marionette.find_element(*self._option_menu_flash_locator)
        while True:
            current_element = self.marionette.get_active_element()
            if target_element == current_element:
                self.press_softkey_central_button()
                break
            else:
                self.press_dpad_down_button()

        if to.lower() == 'on':
            target_sub_panel_element = self.marionette.find_element(*self._option_menu_sub_panel_flash_on_locator)
        elif to.lower() == 'off':
            target_sub_panel_element = self.marionette.find_element(*self._option_menu_sub_panel_flash_off_locator)
        elif to.lower() == 'auto':
            target_sub_panel_element = self.marionette.find_element(*self._option_menu_sub_panel_flash_auto_locator)
        else:
            raise Exception('only put "on", "off", or "auto" here.')

        while True:
            current_sub_panel_element = self.marionette.get_active_element()
            if target_sub_panel_element == current_sub_panel_element:
                self.press_softkey_central_button()
                break
            else:
                self.press_dpad_down_button()

        self.wait_for_flash_notification_finished(status=to)

    def switch_camera_mode(self, to=VIDEO_MODE):
        """
        :param to: 'photo' or 'video'
        :return:
        """
        mode_list = {'photo': self._notification_span_photo_mode_locator,
                     'video': self._notification_span_video_mode_locator}

        current_mode = self.camera_mode
        if current_mode == to.lower():
            return
        else:
            self.press_dpad_up_button()

        self.__wait_for_notification_finished(mode_list[to])

    def record_video(self, duration):
        if self.camera_mode == self.PHOTO_MODE:
            raise Exception("you cannot record video at photo mode!")
        # Start recording
        self.press_softkey_central_button()

        self.wait_for_video_start_capturing()

        # Wait for duration
        timeout = duration + 10
        timer_text = "00:%02d" % duration
        timer = self.marionette.find_element(*self._video_timer_locator)
        Wait(self.marionette, timeout).until(lambda m: timer.text >= timer_text)

        # Stop recording
        self.press_softkey_central_button()

        self.wait_for_stream_capture_ready()

    def wait_for_stream_capture_ready(self):
        viewfinder = Wait(self.marionette).until(expected.element_present(*self._viewfinder_video_locator))
        Wait(self.marionette, timeout=10).until(lambda m: m.execute_script('return arguments[0].readyState;', [viewfinder]) > 0)
        Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette).until(expected.element_present(
                    *self._viewfinder_ready_locator))))

    def wait_for_video_start_capturing(self):
        indicator = self.marionette.find_element(*self._indicator_locator)
        Wait(self.marionette).until(lambda m: indicator.get_attribute('recording') == 'true')

    def wait_for_flash_notification_finished(self, status='on'):
        locator_list = {'on': self._notification_span_flash_on_locator,
                        'off': self._notification_span_flash_off_locator,
                        'auto': self._notification_span_flash_auto_locator}

        self.__wait_for_notification_finished(locator_list[status])

    def __wait_for_notification_finished(self, locator):
        Wait(self.marionette).until(expected.element_present(*locator))
        Wait(self.marionette).until(expected.element_not_present(*locator))

    def __go_to_options_menu(self):
        try:
            option_menu = self.marionette.find_element(*self._option_menu_locator)
            if option_menu.get_attribute('hidden') == 'true':
                self.press_softkey_right_button()
        except NoSuchElementException:
            self.press_softkey_right_button()

class ImagePreview(Gallery):

    def __init__(self, marionette):
        Gallery.__init__(self, marionette)
        self.apps.switch_to_displayed_app()

    @property
    def is_image_preview_visible(self):
        return self.is_element_displayed(*self._fullscreen_view_active_locator)

    def is_preview_image_display(self):
        return self.is_element_present(*self._fullscreen_view_current_photo_locator)
