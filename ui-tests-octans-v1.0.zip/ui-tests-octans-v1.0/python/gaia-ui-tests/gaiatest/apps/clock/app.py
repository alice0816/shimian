# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette import expected
from marionette.by import By
from marionette.wait import Wait
import time

from gaiatest.apps.base import Base

class Clock(Base):

    ## TODO: Aca modifying...

    name = 'Clock'

    _clock_tabs_shown_locator = (By.CSS_SELECTOR, 'h5-tabs-view.clock-tabs')
    _banner_countdown_notification_locator = (By.ID, 'banner-countdown')

    def launch(self):
        Base.launch(self)
        Wait(self.marionette).until(expected.element_displayed(
            Wait(self.marionette).until(expected.element_present(
                *self._clock_tabs_shown_locator))))

        from gaiatest.apps.clock.regions.alarm import AlarmTab
        self.alarm_tab = AlarmTab(self.marionette)

        from gaiatest.apps.clock.regions.timer import TimerTab
        self.timer_tab = TimerTab(self.marionette)

        from gaiatest.apps.clock.regions.stopwatch import StopwatchTab
        self.stopwatch_tab = StopwatchTab(self.marionette)

    @property
    def banner_notification(self):
        banner = Wait(self.marionette).until(
            expected.element_present(*self._banner_countdown_notification_locator))
        Wait(self.marionette).until(expected.element_displayed(banner))
        return banner.text

    def wait_banner_disappear(self):
        banner = Wait(self.marionette).until(
            expected.element_present(*self._banner_countdown_notification_locator))
        Wait(self.marionette).until(expected.element_not_displayed(banner))

    def switch_to_timer_tab(self):
        while True:
            if self.timer_tab.is_timer_tab_displayed():
                return
            else:
                self.press_dpad_right_button()

    def switch_to_alarm_tab(self):
        while True:
            if self.alarm_tab.is_alarm_tab_displayed():
                return
            else:
                self.press_dpad_right_button()

    def switch_to_stopwatch_tab(self):
        while True:
            if self.stopwatch_tab.is_stopwatch_tab_displayed():
                return
            else:
                self.press_dpad_right_button()


    def is_clocktime_running(self, locator, message=""):
        Wait(self.marionette).until(expected.element_present(*locator), message=message)
        time1 = self.marionette.find_element(*locator).text
        time.sleep(1)
        time2 = self.marionette.find_element(*locator).text

        if time1 == time2:
            return False
        else:
            return True