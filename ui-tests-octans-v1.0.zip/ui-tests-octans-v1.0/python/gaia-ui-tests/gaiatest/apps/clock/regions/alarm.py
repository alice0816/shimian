# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time

from marionette import expected
from marionette import Wait
from marionette.by import By

from gaiatest.apps.base import PageRegion
from gaiatest.apps.clock.app import Clock
from gaiatest.apps.system.regions.time_picker import TimePicker

## TODO: Aca modifying...

class AlarmTab(Clock):
    """
        For Feature phone, clock app has 3 tabs.
    """
    _all_alarms_locator = (By.CSS_SELECTOR, '#alarms li')

    _alarm_tab_active_locator = (By.CSS_SELECTOR, '#alarm-panel[class*="active"]')
    _alarm_create_new_button_locator = (By.ID, 'alarm-new-btn')

    def __init__(self, marionette):
        Clock.__init__(self, marionette)

    def is_alarm_tab_displayed(self):
        try:
            Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette, timeout=5).until(expected.element_present(
                    *self._alarm_tab_active_locator))))
            return True
        except:
            return False

    def press_add_alarm_button(self):
        if expected.element_selected(self.marionette.find_element(*self._alarm_create_new_button_locator)):
            self.press_softkey_central_button()
        from gaiatest.apps.clock.regions.alarm import NewAlarm
        return NewAlarm(self.marionette)

    def press_edit_alarm_button(self):
        self.press_softkey_right_button()
        from gaiatest.apps.clock.regions.alarm import EditAlarm
        return EditAlarm(self.marionette)

    @property
    def alarms(self):
        return [self.Alarm(self.marionette, alarm) for alarm in self.marionette.find_elements(*self._all_alarms_locator)]

    def go_to_alarm(self, ordinal):
        if expected.element_selected(self.marionette.find_element(*self._alarm_create_new_button_locator)):
            for move in range(0, ordinal):
                self.press_dpad_down_button()

    class Alarm(PageRegion, Clock):

        _label_locator = (By.CSS_SELECTOR, '.label')
        _check_box_locator = (By.CSS_SELECTOR, '.input-enable')
        _enable_button_locator = (By.CSS_SELECTOR, '.alarmList.alarmEnable')
        _time_locator = (By.CSS_SELECTOR, '.time')

        def time(self):
            return self.root_element.find_element(*self._time_locator).text

        @property
        def label(self):
            return self.root_element.find_element(*self._label_locator).text

        @property
        def is_alarm_active(self):
            return self.root_element.find_element(*self._check_box_locator).is_selected()

        def press_switch_alarm_button(self, switcher=''):
            """
            :param switcher: '' to press anyway, 'on' to trun on, 'off' to turn off
            :return:
            """
            if switcher.lower() == 'on':
                if not self.is_alarm_active:
                    self.press_softkey_central_button()
            elif switcher.lower() == 'off':
                if self.is_alarm_active:
                    self.press_softkey_central_button()
            elif switcher == '':
                self.press_softkey_central_button()

        def wait_for_checkbox_to_change_state(self, value):
            checkbox = self.marionette.find_element(*self._check_box_locator)
            Wait(self.marionette).until(lambda m: checkbox.is_selected() == value)


class NewAlarm(TimePicker):

    _alarm_time_picker_active_CSS = '#alarm-panel[class*="active"] #time-picker-dialog[class="panel skin-dark"]'

    _alarm_time_picker_active_locator = (By.CSS_SELECTOR, _alarm_time_picker_active_CSS)
    _minutes_picker_locator = (By.CSS_SELECTOR, _alarm_time_picker_active_CSS + ' .picker-minutes')

    _hours_picker_focus_checker = (TimePicker._hours_picker_focus_checker[0], _alarm_time_picker_active_CSS + ' ' + TimePicker._hours_picker_focus_checker[1])
    _minutes_picker_focus_checker = (TimePicker._minutes_picker_focus_checker[0], _alarm_time_picker_active_CSS + ' ' + TimePicker._minutes_picker_focus_checker[1])
    _hours24_picker_focus_checker = (TimePicker._hours24_picker_focus_checker[0], _alarm_time_picker_active_CSS + ' ' + TimePicker._hours24_picker_focus_checker[1])

    def __init__(self, marionette):
        TimePicker.__init__(self, marionette)
        view = self.marionette.find_element(*self._alarm_time_picker_active_locator)
        Wait(self.marionette).until(lambda m: view.location['x'] == 0 and view.is_displayed())

    def create_alarm_with_adding_minutes(self, minutes):
        if minutes > 0:
            self.add_minutes(minutes)
        self.press_ok()

    def press_ok(self):
        self.press_softkey_right_button()

class EditAlarm(Clock):

    _delete_button_locator = (By.CSS_SELECTOR, '#alarm-delete')

    def __init__(self, marionette):
        Clock.__init__(self, marionette)

    # def press_delete_button(self):
    #     while True:
    #         if self.marionette.find_element(*self._delete_button_locator):
    #             self.press_softkey_central_button()
    #             # return
    #         else:
    #             self.press_dpad_down_button()
