# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette import expected
from marionette import Wait
from marionette.by import By
from gaiatest.apps.base import Base
from marionette.errors import FrameSendFailureError


class AlarmAlertScreen(Base):
    """
     it is clock app, but different iframes...
    """
    _alarm_frame_locator = (By.CSS_SELECTOR, 'iframe[mozapp*="clock"]:nth-child(1)')
    _stop_button_locator = (By.ID, 'ring-button-stop')
    _alarm_label_locator = (By.ID, 'ring-label')

    def __init__(self, marionette):
        Base.__init__(self, marionette)
        self.marionette = marionette
        self.marionette.switch_to_frame()

    def wait_for_alarm_to_trigger(self, timeout=60):
        alarm_frame = Wait(self.marionette, timeout=timeout).until(
            expected.element_present(*self._alarm_frame_locator))
        Wait(self.marionette).until(expected.element_displayed(alarm_frame))
        #wait 2 seconds for fully displaying alarm iframe
        import time
        time.sleep(2)

    def press_dismiss_alarm_button(self):
        self.press_softkey_right_button()

    def press_snooze_alarm_button(self):
        self.press_softkey_left_button()

    @property
    def alarm_label(self):
        alarm_label = Wait(self.marionette).until(
            expected.element_present(*self._alarm_label_locator))
        Wait(self.marionette).until(expected.element_displayed(alarm_label))
        return alarm_label.text
