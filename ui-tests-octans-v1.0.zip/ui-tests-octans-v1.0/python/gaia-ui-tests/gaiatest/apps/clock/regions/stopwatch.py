# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


from marionette.by import By
from marionette.wait import Wait
from marionette import expected

import time

from gaiatest.apps.clock.app import Clock

## TODO: Aca modifying...

class StopwatchTab(Clock):
    """
        For Feature phone, clock app has 3 tabs.
    """

    _stopwatch_tab_active_locator = (By.CSS_SELECTOR, '#stopwatch-panel[class*="active"]')
    _stopwatch_running_locator = (By.CSS_SELECTOR, '#stopwatch-panel[class*="start"] .stopwatch-time')
    _stopwatch_paused_locator = (By.CSS_SELECTOR, '#stopwatch-panel[class*="pause"] .stopwatch-time')

    def __init__(self, marionette):
        Clock.__init__(self, marionette)

    def is_stopwatch_tab_displayed(self):
        try:
            Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette).until(expected.element_present(
                    *self._stopwatch_tab_active_locator))))
            return True
        except:
            return False

    def press_start_stopwatch(self):
        self.press_softkey_central_button()

    def press_pause_stopwatch(self):
        self.press_softkey_central_button()

    def is_stopwatch_running(self):
        if self.is_clocktime_running(self._stopwatch_running_locator, message="stopwatch is not running?"):
            return True
        else:
            return False

    def is_stopwatch_paused(self):
        if self.is_clocktime_running(self._stopwatch_paused_locator, message="stopwatch is not paused?"):
            return False
        else:
            return True