# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


from marionette.by import By
import time
from marionette.wait import Wait
from marionette import expected

from gaiatest.apps.clock.app import Clock

## TODO: Aca modifying...

class TimerTab(Clock):
    """
        For Feature phone, clock app has 3 tabs.
    """

    _timer_tab_active_locator = (By.CSS_SELECTOR, '#timer-panel[class*="active"]')
    _timer_running_locator = (By.CSS_SELECTOR, '#timer-time[class*="start"]')
    _timer_pausing_locator = (By.CSS_SELECTOR, '#timer-time[class*="pause"]')

    def __init__(self, marionette):
        Clock.__init__(self, marionette)

    def is_timer_tab_displayed(self):
        try:
            Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette, timeout=5).until(expected.element_present(
                    *self._timer_tab_active_locator))))
            return True
        except:
            return False

    def press_start_timer(self):
        self.press_softkey_central_button()

    def press_pause_timer(self):
        self.press_softkey_central_button()

    def is_timer_running(self):
        if self.is_clocktime_running(self._timer_running_locator, message="timer is not running?"):
            return True
        else:
            return False

    def is_timer_paused(self):
        if self.is_clocktime_running(self._timer_pausing_locator, message="timer is not paused?"):
            return False
        else:
            return True