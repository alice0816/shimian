# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette.by import By

from gaiatest.apps.base import Base


class LockScreen(Base):

    _lockscreen_window_locator = (By.CLASS_NAME, 'lockScreenWindow')

    _lockscreen_locator = (By.ID, 'lockscreen')
    _lockscreen_handle_locator = (By.ID, 'lockscreen-area-slide')
    _lockscreen_passcode_code_locator = (By.ID, 'lockscreen-passcode-code')
    _lockscreen_passcode_pad_locator = (By.ID, 'lockscreen-passcode-pad')


    def __init__(self, marionette):
        Base.__init__(self, marionette)
        self.marionette.switch_to_frame()

    def enter_pin_code_to_unlock(self, pin_code):
        if len(pin_code) != 4:
            raise Exception('You need to input 4 digit as your pin code')

        for number in pin_code:
            self.press_number_button(int(number), toSystem=True)
