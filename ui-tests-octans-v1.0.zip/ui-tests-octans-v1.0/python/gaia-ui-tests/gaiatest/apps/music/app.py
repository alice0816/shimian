# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette import expected
from marionette import Wait
from marionette.by import By

from gaiatest.apps.base import Base

class Music(Base):

    ## TODO: Aca modifying...

    name = 'Music'

    _music_title_list = ['Playlist', 'Artists', 'Albums', 'Songs']

    _loading_spinner_locator = (By.ID, 'spinner-overlay')
    _music_tiles_locator = (By.CSS_SELECTOR, '#views-list-header #views-list-title')
    _songs_at_songs_tab_locator = (By.CSS_SELECTOR, '#views-list-anchor li a')

    _overlay_form_display_locator = (By.CSS_SELECTOR, '#overlay:not([class="hidden"])')
    _empty_music_title_locator = (By.CSS_SELECTOR, '#overlay-title[data-l10n-id="empty-title"]')
    _empty_music_text_locator = (By.CSS_SELECTOR, '#overlay-text[data-l10n-id="empty-text"]')

    def launch(self):
        Base.launch(self)
        Wait(self.marionette).until(expected.element_not_displayed(
            *self._loading_spinner_locator))
        Wait(self.marionette).until(expected.element_not_displayed(
            *self._overlay_form_display_locator))

    @property
    def current_music_title(self):
        return self.marionette.find_element(*self._music_tiles_locator).text

    def switch_to_playlist_tab(self):
        self.switch_to_target_tab(self._music_title_list[0])
        if self.current_music_title != self._music_title_list[0]:
            raise Exception('Current tab is not "' + self._music_title_list[0] + '"!')

    def switch_to_artists_tab(self):
        self.switch_to_target_tab(self._music_title_list[1])
        if self.current_music_title != self._music_title_list[1]:
            raise Exception('Current tab is not "' + self._music_title_list[1] + '"!')

    def switch_to_albums_tab(self):
        self.switch_to_target_tab(self._music_title_list[2])
        if self.current_music_title != self._music_title_list[2]:
            raise Exception('Current tab is not "' + self._music_title_list[2] + '"!')

    def switch_to_songs_tab(self):
        self.switch_to_target_tab(self._music_title_list[3])
        if self.current_music_title != self._music_title_list[3]:
            raise Exception('Current tab is not "' + self._music_title_list[3] + '"!')

    def switch_to_target_tab(self, target):
        current_tab_index = self._music_title_list.index(self.current_music_title)
        target_tab_index = self._music_title_list.index(target)
        steps = (target_tab_index - current_tab_index)
        if steps >= 0:
            for number in range(0, steps):
                self.press_dpad_right_button()
        else:
            for number in range(0, abs(steps)):
                self.press_dpad_left_button()

    def play_a_song(self, which):
        """
        :param which: which song do you want to play? (1, 2, 3, ...)
        :return:
        """
        if which < 1:
            raise Exception('You should play 1~n songs, but not 0 or negative int.')

        song_elements = self.marionette.find_elements(*self._songs_at_songs_tab_locator)

        if len(song_elements) > 0:
            for number in range(0, which):
                if number == which - 1:
                    self.press_softkey_central_button()
                    from gaiatest.apps.music.regions.player_view import PlayerView
                    return PlayerView(self.marionette, song_elements[which - 1])
                else:
                    self.press_dpad_down_button()


    def wait_for_empty_message_to_load(self):
        element = self.marionette.find_element(*self._empty_music_title_locator)
        Wait(self.marionette).until(lambda m: not element.text == '')

    @property
    def empty_music_title(self):
        return self.marionette.find_element(*self._empty_music_title_locator).text

    @property
    def empty_music_text(self):
        return self.marionette.find_element(*self._empty_music_text_locator).text
