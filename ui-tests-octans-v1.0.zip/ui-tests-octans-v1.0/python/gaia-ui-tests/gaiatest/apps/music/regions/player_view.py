# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time

from marionette.by import By
from marionette import Wait
from marionette import expected
from marionette.errors import NoSuchElementException

from gaiatest.apps.music.app import Music


class PlayerView(Music):

    ## TODO: Aca modifying...

    _player_view_locator = (By.CSS_SELECTOR, '#views-player[class="view animated current"]')
    _song_title_locator = (By.CSS_SELECTOR, '#views-player #player-cover-title>bdi')

    _control_button_id_list = ['player-album-repeat', 'player-controls-previous', 'player-controls-play', 'player-controls-next', 'player-album-shuffle']

    _repeat_button_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[0])
    _repeat_button_all_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[0]+'[aria-label="Repeat all"]')
    _repeat_button_single_track_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[0]+'[aria-label="Repeat track"]')
    _repeat_button_off_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[0]+'[aria-label="Repeat off"]')
    _previous_button_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[1])
    _play_button_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[2])
    _play_button_play_status_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[2]+'[aria-label="Play"]')
    _play_button_pause_status_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[2]+'[aria-label="Pause"]')
    _next_button_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[3])
    _shuffle_button_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[4])
    _shuffle_button_on_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[4]+'[aria-pressed="true"]')
    _shuffle_button_off_locator = (By.CSS_SELECTOR, '#'+_control_button_id_list[4]+'[aria-pressed="false"]')

    _control_button_locator_list = {_control_button_id_list[0]: _repeat_button_locator,
                                    _control_button_id_list[1]: _previous_button_locator,
                                    _control_button_id_list[2]: _play_button_locator,
                                    _control_button_id_list[3]: _next_button_locator,
                                    _control_button_id_list[4]: _shuffle_button_locator}

    _player_seek_locator = (By.CSS_SELECTOR, '#player-seek')
    _player_seek_elapsed_locator = (By.ID, 'player-seek-elapsed')

    def __init__(self, marionette, played_song_element):
        Music.__init__(self, marionette)
        Wait(self.marionette).until(expected.element_present(*self._player_view_locator))
        if self.get_playing_song_title == played_song_element.get_attribute('data-key-range'):
            return
        else:
            raise Exception('Playing song title does not match the song you played.')

    @property
    def get_playing_song_title(self):
        return self.marionette.find_element(*self._song_title_locator).text

    def press_repeat_button(self):
        self.locate_and_press_control_button(self._control_button_id_list[0])

    def press_previous_button(self):
        self.locate_and_press_control_button(self._control_button_id_list[1])
        time.sleep(2)

    def press_play_button(self):
        self.locate_and_press_control_button(self._control_button_id_list[2])

    def press_pause_button(self, sleep_time=2):
        time.sleep(sleep_time)
        self.locate_and_press_control_button(self._control_button_id_list[2])
        time.sleep(sleep_time)

    def press_next_button(self):
        self.locate_and_press_control_button(self._control_button_id_list[3])
        time.sleep(2)

    def press_shuffle_button(self):
        self.locate_and_press_control_button(self._control_button_id_list[4])

    def switch_shuffle(self, to='on'):
        locator_list = {'on': self._shuffle_button_on_locator,
                        'off': self._shuffle_button_off_locator}
        try:
            locator = locator_list[to.lower()]
            if locator is None:
                raise Exception('"to" only can be input "on" or "off"!')

            while True:
                try:
                    self.marionette.find_element(*locator)
                    return
                except NoSuchElementException:
                    self.press_shuffle_button()
        except:
            raise Exception('shuffle switch failed')

    def switch_repeat(self, to='single'):
        locator_list = {'single': self._repeat_button_single_track_locator,
                   'off': self._repeat_button_off_locator,
                   'all': self._repeat_button_all_locator}
        try:
            locator = locator_list[to.lower()]
            if locator is None:
                raise Exception('"to" only can be input "single", "all" or "off"!')

            while True:
                try:
                    self.marionette.find_element(*locator)
                    return
                except NoSuchElementException:
                    self.press_repeat_button()
        except:
            raise Exception('repeat switch failed')

    def locate_and_press_control_button(self, control_button_id):
        current_focused_element = self.marionette.get_active_element()
        try:
            steps = (self._control_button_id_list.index(control_button_id) - self._control_button_id_list.index(current_focused_element.get_attribute('id')))
            if steps > 0:
                for number in range(0, steps):
                    self.press_dpad_right_button()
            elif steps < 0:
                for number in range(0, abs(steps)):
                    self.press_dpad_left_button()

            self.press_softkey_central_button()
        except:
            raise Exception('Button operation is failed')

    def is_playing(self, waiting=3):
        time_1 = self.marionette.find_element(*self._player_seek_elapsed_locator).text
        time.sleep(waiting)
        time_2 = self.marionette.find_element(*self._player_seek_elapsed_locator).text
        if time_1 == time_2:
            return False
        else:
            return True

    def is_paused(self):
        return not self.is_playing()

    @property
    def player_song_duration(self):
        Wait(self.marionette).until(expected.element_displayed(
            Wait(self.marionette).until(expected.element_present(*self._player_seek_locator))))
        return int(float(self.marionette.find_element(*self._player_seek_locator).get_attribute('aria-valuemax')))

    @property
    def player_elapsed_time(self):
        Wait(self.marionette).until(expected.element_displayed(
            Wait(self.marionette).until(expected.element_present(*self._player_seek_elapsed_locator))))
        return time.strptime(self.marionette.find_element(*self._player_seek_elapsed_locator).text, '%M:%S')
