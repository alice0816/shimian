__author__ = 'hermesc'
from gaiatest import H5NontouchKeypad

class NontouchKeypad(H5NontouchKeypad):

    def __init__(self, marionette):
        H5NontouchKeypad.__init__(self, marionette)

    def press_dpad_up_button(self, toSystem=False):
        self._dispatch_softkey_event('ArrowUp', str(self.keys['DOM_VK_UP']), toSystem)

    def press_dpad_down_button(self, toSystem=False):
        self._dispatch_softkey_event('ArrowDown', str(self.keys['DOM_VK_DOWN']), toSystem)

    def press_dpad_left_button(self, toSystem=False):
        self._dispatch_softkey_event('ArrowLeft', str(self.keys['DOM_VK_LEFT']), toSystem)

    def press_dpad_right_button(self, toSystem=False):
        self._dispatch_softkey_event('ArrowRight', str(self.keys['DOM_VK_RIGHT']), toSystem)

    """
       press LSK, RSK, OK, Call, EndCall
       https://jira.acadine.com/browse/CORE-18
    """
    def press_call_button(self, toSystem=False):
        self._dispatch_softkey_event('AcaCall', 0, toSystem)

    def press_endcall_button(self, toSystem=False):
        self._dispatch_softkey_event('AcaEndCall', 95, toSystem)

    def press_softkey_left_button(self, toSystem=False):
        self._dispatch_softkey_event('AcaSoftLeft', 0, toSystem)

    def press_softkey_central_button(self, toSystem=False):
        self._dispatch_softkey_event('Enter', 13, toSystem)

    def press_softkey_right_button(self, toSystem=False):
        self._dispatch_softkey_event('AcaSoftRight', 0, toSystem)

    def press_sleep_button(self, toSystem=False):
        self._dispatch_softkey_event('Power', 95, toSystem)

    def press_number_button(self, number, toSystem=False):
        keyCode = self.keys['DOM_VK_'+str(number)]
        self._dispatch_softkey_event(number, keyCode, toSystem)

    def _dispatch_softkey_event(self, keyName, keyCode, toSystem=False):
        """

        :param keyName: e.g. 'AcaSoftLeft'
        :param keyCode: from W3C spec
        :return: n/a
        """
        self.marionette.execute_script("""
                                        var currentApp = document.activeElement;
                                        h5OSKeypad.pressSoftKey(arguments[0], arguments[1], currentApp, arguments[2]);
                                       """, script_args=[keyName, str(keyCode), toSystem])