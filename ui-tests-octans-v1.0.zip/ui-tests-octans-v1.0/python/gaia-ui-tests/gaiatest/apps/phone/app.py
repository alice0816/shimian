# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette.by import By
from marionette import expected
from marionette import Wait
from gaiatest.apps.base import Base

class Phone(Base):

    ## TODO: Aca modifying...

    name = "Phone"

    _dialog_locator = (By.ID, 'confirmation-message')
    _dialog_title_locator = (By.XPATH, "//*[@id='confirmation-message']/section/h1")
    _call_log_toolbar_button_locator = (By.ID, 'option-recents')
    _call_log_toolbar_locator = (By.ID, 'recents-panel')
    _contacts_view_locator = (By.ID, 'option-contacts')
    _call_group_menu_locator = (By.CLASS_NAME, 'call-group-menu')
    _cancel_action_menu_locator = (By.ID, 'cancel-action-menu')
    _contacts_toolbar_locator = (By.ID, 'iframe-contacts-container')
    _contacts_frame_locator = (By.ID, 'iframe-contacts')

    _phone_number_container_locator = (By.ID, 'phone-number-view-container')
    _phone_number_field_locator = (By.ID, 'phone-number-view')

    def launch(self):
        Base.launch(self)
        Wait(self.marionette).until(
            expected.element_displayed(*self._phone_number_container_locator))

    @property
    def call_screen(self):
        from gaiatest.apps.phone.regions.call_screen import CallScreen
        return CallScreen(self.marionette)

    @property
    def call_log(self):
        from gaiatest.apps.phone.regions.call_log import CallLog
        return CallLog(self.marionette)

    def press_multiple_numbers(self, numbers):
        # TODO: assert all input numbers are shown in screen
        for number in numbers:
            if number.isdigit():
                self.press_single_number_button(number)
            ## TODO: add input strings (e.g. '+')

    def press_single_number_button(self, number):
        self.press_number_button(number)

    def get_input_number(self):
        return self.marionette.find_element(*self._phone_number_field_locator).get_attribute('value')

    def press_call_button(self):
        super(Phone, self).press_call_button()
        return self.call_screen

    def clear_phonenumber(self, length):
        for i in range(length):
            self.press_clear_button()

    def press_clear_button(self):
        self.press_softkey_left_button()
