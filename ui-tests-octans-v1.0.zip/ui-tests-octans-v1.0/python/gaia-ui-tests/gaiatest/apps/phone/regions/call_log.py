# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette.by import By
from gaiatest.apps.phone.app import Phone

from marionette import Wait
from marionette import expected


class CallLog(Phone):

    ## TODO: Aca modifying...

    _call_log_default_tab_locator = (By.CSS_SELECTOR, '#call-log-container[class="view-body-inner active"]')
    _call_log_view_locator = (By.ID, 'call-log-view')

    _call_log_all_tab_locator = _call_log_default_tab_locator
    _call_log_missed_tab_locator = (By.CSS_SELECTOR, '#call-log-container[class="view-body-inner active missed-filter"]')
    _call_log_answered_tab_locator = (By.CSS_SELECTOR, '#call-log-container[class="view-body-inner active answered-filter"]')
    _call_log_dialed_tab_locator = (By.CSS_SELECTOR, '#call-log-container[class="view-body-inner active dialed-filter"]')
    _call_log_all_tab_log_list_locator = (By.CSS_SELECTOR, '#call-log-container[class="view-body-inner active"] ol li[class*=log-item]')
    _call_log_missed_tab_log_list_locator = (By.CSS_SELECTOR, '#call-log-container[class*="missed-filter"] ol li[class*=missed-call]')
    _call_log_answered_tab_log_list_locator = (By.CSS_SELECTOR, '#call-log-container[class*="answered-filter"] ol li[class*=answered-call]')
    _call_log_dialed_tab_log_list_locator = (By.CSS_SELECTOR, '#call-log-container[class*="dialed-filter"] ol li[class*=dialed-call]')

    _call_log_option_menu = (By.CSS_SELECTOR, '#option-menu-root>h5-option-menu:not([hidden])')
    _call_log_option_menu_remove_entry = (By.CSS_SELECTOR, '#option-menu-root .h5-option-menu-item[data-title="Remove entry"]')
    _call_log_option_menu_clear_all = (By.CSS_SELECTOR, '#option-menu-root .h5-option-menu-item[data-title="Clear all"]')

    def __init__(self, marionette):
        Phone.__init__(self, marionette)
        self.apps.switch_to_displayed_app()
        self.wait_for_element_displayed(*self._call_log_default_tab_locator)

    def is_call_log_launched(self):
        try:
            Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette, timeout=5).until(expected.element_present(
                    *self._call_log_view_locator))))
            return True
        except:
            return False

    def is_all_tab_displayed(self):
        return self.is_tab_displayed(self._call_log_all_tab_locator)

    def is_missed_tab_displayed(self):
        return self.is_tab_displayed(self._call_log_missed_tab_locator)

    def is_answered_tab_displayed(self):
        return self.is_tab_displayed(self._call_log_answered_tab_locator)

    def is_dialed_tab_displayed(self):
        return self.is_tab_displayed(self._call_log_dialed_tab_locator)

    def is_tab_displayed(self, locator):
        try:
            Wait(self.marionette).until(expected.element_displayed(
                Wait(self.marionette).until(expected.element_present(
                    *locator))))
            return True
        except:
            return False

    def get_all_tab_record_count(self):
        return len(self.marionette.find_elements(*self._call_log_all_tab_log_list_locator))

    def get_missed_tab_record_count(self):
        return len(self.marionette.find_elements(*self._call_log_missed_tab_log_list_locator))

    def get_answered_tab_record_count(self):
        return len(self.marionette.find_elements(*self._call_log_answered_tab_log_list_locator))

    def get_dialed_tab_record_count(self):
        return len(self.marionette.find_elements(*self._call_log_dialed_tab_log_list_locator))

    def switch_to_missed_tab(self):
        while True:
            if self.is_missed_tab_displayed():
                return
            else:
                self.press_dpad_right_button()

    def switch_to_answered_tab(self):
        while True:
            if self.is_answered_tab_displayed():
                return
            else:
                self.press_dpad_right_button()

    def switch_to_dialed_tab(self):
        while True:
            if self.is_dialed_tab_displayed():
                return
            else:
                self.press_dpad_right_button()

    def enter_options_menu(self):
        ## TODO: sometimes, the active DOM does not handle key event?
        self.press_softkey_right_button()
        self.marionette.find_element(*self._call_log_option_menu)

    def perform_remove_entry(self):
        self.locate_remove_entry_on_options_menu()
        self.press_softkey_central_button()

    def perform_clear_all(self):
        self.locate_clear_all_on_options_menu()
        self.press_softkey_central_button()

    def locate_remove_entry_on_options_menu(self, starter=0):
        """
        :param starter: where are you?
        :return:
        """
        self.locate_option_menu_entry(self._call_log_option_menu_remove_entry, starter)

    def locate_clear_all_on_options_menu(self, starter=0):
        """
        :param starter: where are you?
        :return:
        """
        self.locate_option_menu_entry(self._call_log_option_menu_clear_all, starter)

    def locate_option_menu_entry(self, locator, starter):
        index_id = int(self.marionette.find_element(*locator).get_attribute('data-index-id'))
        for number in range(starter, index_id):
            self.press_dpad_down_button()
