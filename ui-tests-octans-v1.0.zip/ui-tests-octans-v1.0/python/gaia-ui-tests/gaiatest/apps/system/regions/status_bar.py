# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from marionette.by import By
from gaiatest.apps.base import PageRegion


class StatusBar(PageRegion):

    _status_bar_time_locator = (By.ID, 'statusbar-time')
    _status_bar_maximized_wrapper = (By.ID, 'statusbar-maximized-wrapper')
    _status_bar_minimized_wrapper = (By.ID, 'statusbar-minimized-wrapper')

    _statusbar_alarm_locator = (By.CSS_SELECTOR, '#statusbar-minimized-wrapper #statusbar-alarm:not([hidden])')
    _statusbar_time_locator = (By.CSS_SELECTOR, '#statusbar-maximized-wrapper #statusbar-time:not([hidden])')
    _statusbar_battery_charging_locator = (By.CSS_SELECTOR, '#statusbar-maximized-wrapper #statusbar-battery[data-charging="true"]')
    _statusbar_mobile_connection_locator = (By.CSS_SELECTOR, '#statusbar-maximized-wrapper #statusbar-mobile-connection .statusbar-signal[data-level]')

    @property
    def is_displayed(self):
        return self.root_element.is_displayed()

    def is_alarm_icon_displayed(self):
        self.marionette.switch_to_frame()
        ## TODO: use base.wait_for_element_displayed() but got failed now...
        import time
        time.sleep(30)
        return self.is_element_present(*self._statusbar_alarm_locator)

    @property
    def is_battery_charging_icon_displayed(self):
        self.marionette.switch_to_frame()
        ## TODO: use base.wait_for_element_displayed() but got failed now...
        return self.is_element_present(*self._statusbar_battery_charging_locator)

    @property
    def is_mobile_connection_icon_displayed(self):
        self.marionette.switch_to_frame()
        ## TODO: use base.wait_for_element_displayed() but got failed now...
        return self.is_element_present(*self._statusbar_mobile_connection_locator)

    @property
    def system_time_at_statusbar(self):
        self.marionette.switch_to_frame()
        return self.marionette.find_element(*self._statusbar_time_locator).text