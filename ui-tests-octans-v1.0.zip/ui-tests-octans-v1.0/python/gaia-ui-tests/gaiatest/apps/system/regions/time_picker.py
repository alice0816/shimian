# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time

from marionette import expected, Wait
from marionette.by import By
from marionette.marionette import Actions

from gaiatest.apps.base import Base


class TimePicker(Base):
    ## TODO: Aca modifying...
    """
        Current layout: (ex)
            Hours   Minutes  Hour-24
              1       00       AM
    """

    _time_picker_locator = (By.CLASS_NAME, 'value-selector-time-picker')
    _done_button_locator = (By.CSS_SELECTOR,
                            '.value-selector-time-picker-buttons > button.value-selector-confirm')

    _hour_picker_locator = (By.CLASS_NAME, 'picker-hours')
    _minutes_picker_locator = (By.CLASS_NAME, 'picker-minutes')
    _hour24_picker_locator = (By.CLASS_NAME, 'picker-hour24State')

    _hours_picker_focus_checker = (By.CSS_SELECTOR, '.value-indicator-hours:not([hidden])')
    _minutes_picker_focus_checker = (By.CSS_SELECTOR, '.value-indicator-minutes:not([hidden])')
    _hours24_picker_focus_checker = (By.CSS_SELECTOR, '.value-indicator-hour24State:not([hidden])')
    _picker_checker_list = {'hours': _hours_picker_focus_checker, 'minutes': _minutes_picker_focus_checker, 'hours24': _hours24_picker_focus_checker}

    def __init__(self, marionette):
        Base.__init__(self, marionette)
        hour_picker = self.marionette.find_element(*self._hour_picker_locator)
        Wait(self.marionette).until(expected.element_displayed(hour_picker))
        self.frame = self.marionette.get_active_frame()

    def add_minutes(self, adding_m):
        self.go_to_minutes_feild()
        for num in range(0, adding_m):
            self.press_dpad_down_button()

    def go_to_minutes_feild(self):
        self.move_picker_focus('minutes')

    def go_to_hours_feild(self):
        self.move_picker_focus('hours')

    def go_to_hours24_feild(self):
        self.move_picker_focus('hours24')

    def move_picker_focus(self, picker_name):
        mapper = {'hours': 0, 'minutes': 1, 'hours24':2}
        match_key = ''
        ## locate current focus
        for key, value in self._picker_checker_list.iteritems():
            try:
                self.marionette.find_element(*value)
                match_key = key
                break
            except:
                continue

        if match_key == '':
            raise Exception('did not match any time picker field!')

        # > 0: move right
        # < 0: move left
        # = 0: keep focus
        move_direction = mapper[picker_name] - mapper[match_key]
        if move_direction == 0:
            return
        elif move_direction > 0:
            for num in range(0, move_direction):
                self.press_dpad_right_button()
        elif move_direction < 0:
            for num in range(0, -1*move_direction):
                self.press_dpad_left_button()