# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock
from gaiatest.apps.system.app import System


class TestClockCreateNewAlarm(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()
        self.assertEquals(self.clock.alarm_tab.is_alarm_tab_displayed(), True)

    def test_clock_create_new_alarm(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3459
        """

        initial_alarms_count = len(self.clock.alarm_tab.alarms)

        # Set the time on the device
        _seconds_since_epoch = self.marionette.execute_script("""
                var today = new Date();
                var yr = today.getFullYear();
                var mth = today.getMonth();
                var day = today.getDate();
                return new Date(yr, mth, day, 1, 0, 0).getTime();""")

        self.data_layer.set_time(_seconds_since_epoch)

        # create a new alarm which will alarm in 1 more minute
        new_alarm = self.clock.alarm_tab.press_add_alarm_button()
        new_alarm.create_alarm_with_adding_minutes(1)

        # verify the banner-countdown message appears
        alarm_msg = self.clock.banner_notification
        self.assertTrue('The alarm is set for' in alarm_msg, 'Actual banner message was: "' + alarm_msg + '"')
        self.clock.wait_banner_disappear()

        # ensure the new alarm has been added and it is displayed
        self.assertTrue(initial_alarms_count < len(self.clock.alarm_tab.alarms),
                        'Alarms count did not increment')

        self.assertEquals(System(self.marionette).status_bar.is_alarm_icon_displayed(), True)

    ## We use GaiaTestCase.cleanup_data() to clean up alarms when using '--restart'
