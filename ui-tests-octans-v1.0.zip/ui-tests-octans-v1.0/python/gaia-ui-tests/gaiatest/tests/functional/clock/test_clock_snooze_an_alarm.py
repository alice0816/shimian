# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock
from gaiatest.apps.clock.regions.alarm_alert import AlarmAlertScreen
from gaiatest.apps.homescreen.app import Homescreen
from gaiatest.apps.system.app import System


class TestClockSnoozeAnAlarm(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()
        self.assertEquals(self.clock.alarm_tab.is_alarm_tab_displayed(), True)

        ##TODO: use indexedDB to add alarm

        # Set the time on the device
        _seconds_since_epoch = self.marionette.execute_script("""
                var today = new Date();
                var yr = today.getFullYear();
                var mth = today.getMonth();
                var day = today.getDate();
                return new Date(yr, mth, day, 1, 0, 0).getTime();""")

        self.data_layer.set_time(_seconds_since_epoch)

        # create a new alarm which will alarm in 1 more minute
        new_alarm = self.clock.alarm_tab.press_add_alarm_button()
        new_alarm.create_alarm_with_adding_minutes(1)
        self.device.touch_home_button()
        self.marionette.switch_to_frame()

    def test_clock_snooze_an_alarm(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10777
        """
        self.alarm_alert = AlarmAlertScreen(self.marionette)
        self.alarm_alert.wait_for_alarm_to_trigger()

        self.alarm_alert.press_snooze_alarm_button()
        self.assertEquals(System(self.marionette).status_bar.is_alarm_icon_displayed(), True)

        self.alarm_alert.wait_for_alarm_to_trigger(timeout=360)
        self.alarm_alert.press_dismiss_alarm_button()

        self.wait_for_condition(lambda m: self.apps.displayed_app.name == Homescreen.name)

        ##TODO: failed now, but not sure if resulted from https://jira.acadine.com/browse/CORE-1566
        import time
        time.sleep(2)

        # no alarm icon on status bar
        self.assertEquals(System(self.marionette).status_bar.is_alarm_icon_displayed(), False)

    ## We use GaiaTestCase.cleanup_data() to clean up alarms when using '--restart'
