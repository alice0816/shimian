# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock

class TestClockStartPauseStopwatch(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()
        self.clock.switch_to_stopwatch_tab()

    def test_clock_start_stopwatch(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10781
        """

        self.clock.stopwatch_tab.press_start_stopwatch()
        self.assertTrue(self.clock.stopwatch_tab.is_stopwatch_running())

    def test_clock_pause_stopwatch(self):

        self.clock.stopwatch_tab.press_start_stopwatch()
        self.assertTrue(self.clock.stopwatch_tab.is_stopwatch_running())
        self.clock.stopwatch_tab.press_pause_stopwatch()
        self.assertTrue(self.clock.stopwatch_tab.is_stopwatch_paused())

    def tearDown(self):
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)
