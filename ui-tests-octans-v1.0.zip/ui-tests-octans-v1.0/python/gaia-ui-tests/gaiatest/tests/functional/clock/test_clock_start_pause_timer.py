# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock
import time


class TestClockStartPauseTimer(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()
        self.clock.switch_to_timer_tab()

    def test_clock_start_timer(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10780
        """

        self.clock.timer_tab.press_start_timer()
        self.assertTrue(self.clock.timer_tab.is_timer_running())

    def test_clock_pause_timer(self):

        self.clock.timer_tab.press_start_timer()
        self.assertTrue(self.clock.timer_tab.is_timer_running())
        time.sleep(3)
        self.clock.timer_tab.press_pause_timer()
        self.assertTrue(self.clock.timer_tab.is_timer_paused())

    def tearDown(self):
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)