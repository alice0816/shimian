# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock
from gaiatest.apps.system.app import System


class TestClockTurnOffAnAlarm(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()
        self.assertEquals(self.clock.alarm_tab.is_alarm_tab_displayed(), True)

        ## TODO: use indexedDB to enable default alarm
        #default alarm count = 1, and we also keep 1 alarm
        self.alarms_count = len(self.clock.alarm_tab.alarms)
        if self.alarms_count == 0 :
            new_alarm = self.clock.alarm_tab.press_add_alarm_button()
            new_alarm.create_alarm_with_adding_minutes(5)
            self.alarms_count = len(self.clock.alarm_tab.alarms)

        self.clock.alarm_tab.go_to_alarm(1)
        self.clock.alarm_tab.alarms[0].press_switch_alarm_button('on')
        self.clock.alarm_tab.press_dpad_up_button()

        #only 1 alarm from a fresh env
        self.assertEquals(self.alarms_count, 1)
        self.assertEquals(self.clock.alarm_tab.alarms[0].is_alarm_active, True)

    def test_clock_turn_off_an_alarm(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10778
        """

        self.clock.alarm_tab.go_to_alarm(1)
        self.clock.alarm_tab.alarms[0].press_switch_alarm_button()
        self.assertEquals(System(self.marionette).status_bar.is_alarm_icon_displayed(), False)