__author__ = 'hermesc'

from gaiatest import GaiaTestCase
from gaiatest.apps.phone.app import Phone
from gaiatest.apps.homescreen.app import Homescreen


class TestCallLogDeleteRecord(GaiaTestCase):

    def setUp(self):

        GaiaTestCase.setUp(self)

        ## TODO: use indexedDB?
        self.callnumber_1 = self.testvars['remote_phone_numbers'][0]
        self.callnumber_2 = self.testvars['remote_phone_numbers'][1]
        self.phone = Phone(self.marionette)
        self.phone.launch()
        self.phone.press_multiple_numbers(self.callnumber_1)
        self.assertEqual(self.phone.get_input_number(), self.callnumber_1)
        call_screen_1 = self.phone.press_call_button()
        call_screen_1.wait_for_outgoing_call()
        call_screen_1.press_endcall_button()

        self.device.touch_home_button()
        self.phone.launch()

        self.phone.press_multiple_numbers(self.callnumber_2)
        self.assertEqual(self.phone.get_input_number(), self.callnumber_2)
        call_screen_2 = self.phone.press_call_button()
        call_screen_2.wait_for_outgoing_call()
        call_screen_2.press_endcall_button()

        self.device.touch_home_button()
        self.homescreen = Homescreen(self.marionette)

        self.call_log = self.homescreen.launch_call_log_via_press_call_button()
        self.assertTrue(self.call_log.is_call_log_launched(), True)


    def test_call_log_delete_record_remove_entry(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10790
        """
        #assert All tab (2 record)
        self.assertTrue(self.call_log.get_all_tab_record_count() == 2, True)

        self.call_log.enter_options_menu()
        self.call_log.perform_remove_entry()

        #assert All tab (1 record)
        self.assertTrue(self.call_log.get_all_tab_record_count() == 1, True)

    def test_call_log_delete_record_clear_all(self):

        #assert All tab (2 record)
        self.assertTrue(self.call_log.get_all_tab_record_count() == 2, True)

        self.call_log.enter_options_menu()
        self.call_log.perform_clear_all()

        #assert All tab (0 record)
        self.assertTrue(self.call_log.get_all_tab_record_count() == 0, True)

    def tearDown(self):
        self.call_log.enter_options_menu()
        self.call_log.perform_clear_all()
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)
