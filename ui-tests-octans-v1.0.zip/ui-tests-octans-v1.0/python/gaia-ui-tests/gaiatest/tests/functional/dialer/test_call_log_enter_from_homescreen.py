__author__ = 'hermesc'

from gaiatest import GaiaTestCase
from gaiatest.apps.homescreen.app import Homescreen


class TestCallLogEnterFromHomescreen(GaiaTestCase):

    def setUp(self):

        GaiaTestCase.setUp(self)
        self.device.touch_home_button()
        self.homescreen = Homescreen(self.marionette)

    def test_call_log_enter_from_homescreen(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3550
        """
        self.call_log = self.homescreen.launch_call_log_via_press_call_button()
        self.assertTrue(self.call_log.is_call_log_launched(), True)

