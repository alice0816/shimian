__author__ = 'hermesc'

from gaiatest import GaiaTestCase
from gaiatest.apps.phone.app import Phone
from gaiatest.apps.homescreen.app import Homescreen


class TestCallLogWithRecord(GaiaTestCase):

    def setUp(self):

        GaiaTestCase.setUp(self)

        ## TODO: use indexedDB?
        self.phone = Phone(self.marionette)
        self.phone.launch()
        self.callnumber = self.testvars['remote_phone_number']
        self.phone.press_multiple_numbers(self.callnumber)
        self.assertEqual(self.phone.get_input_number(), self.callnumber)
        call_screen = self.phone.press_call_button()
        call_screen.wait_for_outgoing_call()
        call_screen.press_endcall_button()
        self.device.touch_home_button()
        self.homescreen = Homescreen(self.marionette)

    def test_call_log_with_record(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3477
        """
        self.call_log = self.homescreen.launch_call_log_via_press_call_button()
        self.assertTrue(self.call_log.is_call_log_launched(), True)

        #assert All tab (1 record)
        self.assertTrue(self.call_log.get_all_tab_record_count() == 1, True)
        #assert Missed tab (no)
        self.call_log.switch_to_missed_tab()
        self.assertTrue(self.call_log.get_missed_tab_record_count() == 0, True)
        #assert Answered tab (no)
        self.call_log.switch_to_answered_tab()
        self.assertTrue(self.call_log.get_answered_tab_record_count() == 0, True)
        #assert Dailed tab (1 record)
        self.call_log.switch_to_dialed_tab()
        self.assertTrue(self.call_log.get_dialed_tab_record_count() == 1, True)

