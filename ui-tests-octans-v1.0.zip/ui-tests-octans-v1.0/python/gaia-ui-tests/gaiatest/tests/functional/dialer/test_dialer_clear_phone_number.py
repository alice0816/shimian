__author__ = 'hermesc'

from gaiatest import GaiaTestCase
from gaiatest.apps.phone.app import Phone


class TestDialerClearPhoneNumber(GaiaTestCase):

    def setUp(self):

        GaiaTestCase.setUp(self)

        self.phone = Phone(self.marionette)
        self.phone.launch()
        self.callnumber = self.testvars['remote_phone_number']

    def test_dialer_clear_phone_number(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10794
        """
        length = len(self.callnumber)

        self.phone.press_multiple_numbers(self.callnumber)
        self.assertEqual(self.phone.get_input_number(), self.callnumber)
        self.phone.clear_phonenumber(length)
        self.assertEqual(self.phone.get_input_number(), '')
