__author__ = 'hermesc'

from gaiatest import GaiaTestCase
from gaiatest.apps.phone.app import Phone


class TestDialerMakeACallOut(GaiaTestCase):

    def setUp(self):

        GaiaTestCase.setUp(self)

        self.phone = Phone(self.marionette)
        self.phone.launch()
        self.callnumber = self.testvars['remote_phone_number']

    def test_dialer_make_a_call_out(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3466
        """

        self.phone.press_multiple_numbers(self.callnumber)
        self.assertEqual(self.phone.get_input_number(), self.callnumber)
        call_screen = self.phone.press_call_button()
        call_screen.wait_for_outgoing_call()
        call_screen.press_endcall_button()

    def tearDown(self):
        # In case the assertion fails this will still kill the call
        # An open call creates problems for future tests
        self.data_layer.kill_active_call()
        GaiaTestCase.tearDown(self)