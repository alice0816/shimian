# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time
from gaiatest import GaiaTestCase
from gaiatest.apps.music.app import Music

class TestMusicNextAndPrevious(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.push_resource('MUS_0003_30sec.mp3') #title: MUS_0003_30sec
        self.push_resource('MUS_0004_30sec.mp3') #title: MUS_0004_30sec
        self.music = Music(self.marionette)
        self.music.launch()
        self.music.switch_to_songs_tab()

    def test_music_play_next_song(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-11006
        """

        player_view = self.music.play_a_song(1)
        self.assertTrue(player_view.is_playing())

        song_1_title = player_view.get_playing_song_title
        player_view.press_next_button()
        song_2_title = player_view.get_playing_song_title
        self.assertNotEqual(song_1_title, song_2_title, msg="after press next button, the song does not change!")

    def test_music_play_back_to_beginning(self):

        player_view = self.music.play_a_song(2)
        self.assertTrue(player_view.is_playing())

        time.sleep(10) # press back to beginning after song has been played > 10 sec
        song_1_title = player_view.get_playing_song_title

        player_view.press_previous_button()

        self.assertTrue(player_view.player_elapsed_time < time.strptime('00:10', '%M:%S'))
        song_2_title = player_view.get_playing_song_title
        self.assertEqual(song_1_title, song_2_title, msg="after press previous button after 10 more seconds, the song must keep the same one!")

    def tearDown(self):
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)
