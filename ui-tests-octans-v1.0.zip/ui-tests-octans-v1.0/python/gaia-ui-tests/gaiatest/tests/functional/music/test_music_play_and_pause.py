# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.music.app import Music


class TestMusicPlayAndPause(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)
        self.push_resource('MUS_0001.mp3')
        self.music = Music(self.marionette)
        self.music.launch()
        self.music.switch_to_songs_tab()

    def test_music_play_a_song(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10783
        """
        player_view = self.music.play_a_song(1)
        self.assertTrue(player_view.is_playing())

    def test_music_pause_a_song(self):

        player_view = self.music.play_a_song(1)
        self.assertTrue(player_view.is_playing())

        player_view.press_pause_button(sleep_time=3)
        self.assertTrue(player_view.is_paused())

    def tearDown(self):
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)