# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

import time
from gaiatest import GaiaTestCase
from gaiatest.apps.music.app import Music

class TestMusicRepeatSinglePlay(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.push_resource('MUS_0001.mp3') #title: My Title
        self.push_resource('MUS_0002.mp3') #title: My Music At Home

    def test_music_repeat_single_play(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3444
        """
        music = Music(self.marionette)
        music.launch()
        music.switch_to_songs_tab()
        player_view = music.play_a_song(1)
        self.assertTrue(player_view.is_playing())

        player_view.switch_repeat(to='single')
        current_song_title = player_view.get_playing_song_title
        time.sleep(player_view.player_song_duration + 3)
        self.assertEqual(current_song_title, player_view.get_playing_song_title)

    def tearDown(self):
        self.apps.kill_all()
        GaiaTestCase.tearDown(self)
