# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.clock.app import Clock

class TestHomeKeyevent(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        self.clock = Clock(self.marionette)
        self.clock.launch()

    def test_home_keyevent(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3438
        """
        self.device._dispatch_home_button_event()
        self.assertEqual(self.apps.displayed_app.name.lower(), self.apps.homescreen_app.lower())

