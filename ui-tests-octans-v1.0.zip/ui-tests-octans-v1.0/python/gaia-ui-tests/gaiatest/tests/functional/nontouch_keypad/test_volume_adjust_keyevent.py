# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.system.app import System

class TestVolumeAdjustKeyevent(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)
        #make phone silence before test

    def test_volume_adjust_keyevent(self):
        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-3540
        """
        system = System(self.marionette)
        self.device.press_volume_up_button()
        self.assertEqual(system.volume_field_number, 1)

        self.device.press_volume_down_button()
        self.assertEqual(system.volume_field_number, 0)



