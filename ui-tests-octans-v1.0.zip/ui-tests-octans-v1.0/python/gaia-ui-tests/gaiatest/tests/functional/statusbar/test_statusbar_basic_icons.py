# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from gaiatest import GaiaTestCase
from gaiatest.apps.system.app import System


class TestStatusbarBasicIcons(GaiaTestCase):

    def setUp(self):
        GaiaTestCase.setUp(self)

        #set system time to 00:00
        _seconds_since_epoch = self.marionette.execute_script("""
                var today = new Date();
                var yr = today.getFullYear();
                var mth = today.getMonth();
                var day = today.getDate();
                return new Date(yr, mth, day, 1, 0, 0).getTime();""")

        self.data_layer.set_time(_seconds_since_epoch)

    def test_statusbar_basic_icons(self):

        """
          Test Link:
            https://testlink.acadine.com/linkto.php?tprojectPrefix=FP&item=testcase&id=FP-10817
        """
        system = System(self.marionette)
        #verify time
        self.assertTrue(system.status_bar.system_time_at_statusbar >= '1:00', True)
        self.assertTrue('1:01' >= system.status_bar.system_time_at_statusbar, True)

        #verify battery icon
        self.assertTrue(system.status_bar.is_battery_charging_icon_displayed, True)

        #verify mobile signal icon
        self.assertTrue(system.status_bar.is_mobile_connection_icon_displayed, True)
